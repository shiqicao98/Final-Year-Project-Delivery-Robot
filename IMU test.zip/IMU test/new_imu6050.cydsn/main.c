/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include <mpu6050.h>
#include <math.h>
//=====================================================================
//Ratios de conversion
#define A_R 16384.0   //Conversion del aceleracion
#define G_R 131.07     //Conversion del giroscopio 

//Conversion de radianes y grados 
#define RAD_TO_DEG  57.2957795
#define DEG_TO_RAD 0.017453
//=====================================================================
int16_t CAX, CAY, CAZ; 
int16_t CGX, CGY, CGZ;  
int16_t t;
float temperature;
float Q_angle = 0.001f;
float Q_bias = 0.003f;
float R_measure = 0.03f;
float angle = 0;
float bias = 0;
float P_00 = 0.0f;
float P_01 = 0.0;
float P_10 = 0.0;
float P_11 = 0.0;
float IMU_anglevel;
float theta_6050;
float x_acc;
float y_acc;
float z_acc;
float cos_slop = 0;
float slop_offset= 0;
float real_acc = 0;
char buf[200];
float offset = 0;
//=====================================================================


CY_ISR(Timer_Handler_IMU){
    Timer_1_ReadStatusRegister();
    MPU6050_getMotion6t(&CAX, &CAY, &CAZ, &CGX, &CGY, &CGZ,&t); 
    temperature = t;
    IMU_anglevel = -CGZ/G_R - offset; //0.94
    
    theta_6050 = theta_6050 + IMU_anglevel *0.02;
    
}

//=====================================================================

int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    I2C_MPU6050_Start();
    SERIAL_Start();
    SERIAL_PutString("xxxxxx\n");
    MPU6050_init();
    MPU6050_initialize();
    SERIAL_PutString("nnnnnn\n");
    Timer_1_Start();
    for(int i = 0; i < 6000;i++){
        MPU6050_getMotion6t(&CAX, &CAY, &CAZ, &CGX, &CGY, &CGZ,&t); 
        offset+=-CGZ/G_R;
    }
    offset = 2.2;
    int time_flag =0;
    isr_1_StartEx(Timer_Handler_IMU);
    for(;;)
    {    
        
        char sign_1 = ' ';
        char sign_2 = ' ';
        time_flag = time_flag+ 1;
        
        int print_imu_AV_upper = IMU_anglevel;
        int print_imu_AV = IMU_anglevel *1000 - print_imu_AV_upper*1000;
        if(IMU_anglevel < 0)
        {
            print_imu_AV = -1*print_imu_AV;
            if(print_imu_AV_upper == 0){sign_1 = '-';}
        }
        
        int print_theta_6050_upper = theta_6050;
        int print_theta_6050 = theta_6050 *1000 - print_theta_6050_upper *1000;
        
        if(theta_6050 < 0)
        {
            print_theta_6050 = -1*print_theta_6050;
            if(print_theta_6050_upper == 0){sign_2 = '-';}
        }
        
        int print_temperature = temperature;

        sprintf(buf, "%4d  angular velocity: %5.5f  theta :%5.5f   temperature    :%1.1f \n" ,time_flag,IMU_anglevel,theta_6050,temperature);
        SERIAL_PutString(buf);
        
        /*
        char sign_3 = ' ';
        int print_x_IMU = x_IMU*1000;
        int print_y_IMU = y_IMU*1000;
        int print_thata_imu = theta_IMU*RAD_TO_DEG;
        int print_real_acc = real_acc;
        int print_linear_IMU_upper = linear_IMU ;
        int print_linear_IMU = linear_IMU * 1000 - print_linear_IMU_upper*1000;
        if(linear_IMU < 0)
        {
            print_linear_IMU = -1*print_linear_IMU;
            if(print_linear_IMU_upper == 0){sign_3 = '-';}
        }
        sprintf(buf, "x_IMU:%d  y_IMU:%d  theta:%d  real_acc %d   sgudu %c%d.%.3d \n",print_x_IMU,print_y_IMU,print_thata_imu,print_real_acc,sign_3,print_linear_IMU_upper,print_linear_IMU);
        SERIAL_PutString(buf);
        SERIAL_PutString("\n\r");
        */
        CyDelay(150);
        
        
   }
}

/* [] END OF FILE */
