/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <math.h>
#include <stdio.h>
float Q_angle = 0.001f;
float Q_bias = 0.003f;
float R_measure = 0.03f;
float theta_6050 = 0;
float bias = 0;
float P_00 = 0;
float P_01 = 0;
float P_10 = 0;
float P_11 = 0;
float IMU_anglevel;
//==========barcode=============
int barcode_counter = 0;
float bar_x_end,bar_y_end,bar_x_start,bar_y_start;
//==============================
// end point==========
float x_end = 0;
float y_end = 0;
// 5 - x -  6.56 + 0.6;  y - 1.04 + 0.8;
//3 - x -1.5; y - 6;
// 1 x - 1.5 y - 2;
//2 x y 4.3 4.3
//===================
#define A_R 16384.0   //Conversion del aceleracion
#define G_R 131.07     //Conversion del giroscopio 

//Conversion de radianes y grados 
#define RAD_TO_DEG  57.2957795
#define DEG_TO_RAD 0.017453
//=========== PID=============
int delt_dist_B = 0;
int  delt_dist= 0;
int PWM_left = 0;
int PWM_right = 0;
int speed_delt = 0;
float D_p;
float D_d;
float D_i;
int P_distance;
//=============================
float start_x = 0;
float start_y = 0;
float start_theta = 0;
float point_in_1_x = 0.4;
float point_in_1_y =2.8;
double get_count2;
double get_count1;
char buf[2000];
char buf2[2000];
int list[100];
int flag = 0;
float angle = 0;
// parimater for pridect---------------------
float scale = 1300;
float linear_velocity;
float angular_velocity;
float wheel_radius = 0.0312;
float baseline = 0.278;
float x = 0,y = 0,theta = 0;
float dt = 0.02;

// speed  tickes per second------------
float speed_1 = 0;
float speed_2 = 0;


// IMU--------------------
int counter_IMU = 0;
int a;
long int b,c,d,e,f;
long int rot_x,rot_y,rot_z;
long int acc_x,acc_y,acc_z;
int16_t CAX, CAY, CAZ; 
int16_t CGX, CGY, CGZ;  
int16_t t;
int distinguish;
//--------------------------
// IMU to state 
float y_error_acc = 0;
float z_error_acc = 10000;
float angle_IMU;
float linear_IMU;
float linear_IMU_acc;
float anglular_IMU;
float dt_IMU = 0.05;
float x_IMU = 0,y_IMU = 0,theta_IMU = 0;
//---------------------
//UTRLA
float distance_measured;
float distance_measured_filter;
uint16_t count;
//---------------------------along the wall
void right_forward(){
Pin_1_Write(1);
Pin_2_Write(0);
}
void right_backward(){
Pin_1_Write(0);
Pin_2_Write(1);
}
void left_forward(){
Pin_3_Write(1);
Pin_4_Write(0);
}
void left_backward(){
Pin_3_Write(0);
Pin_4_Write(1);
}
void left_stop(){
Pin_3_Write(1);
Pin_4_Write(1);
}
void right_stop(){
Pin_1_Write(1);
Pin_2_Write(1);
}
int temp_data_x;
int temp_data_y;
int temp_data_dist;