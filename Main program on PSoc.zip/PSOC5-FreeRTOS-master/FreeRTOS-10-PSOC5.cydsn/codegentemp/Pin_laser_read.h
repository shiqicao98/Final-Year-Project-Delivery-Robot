/*******************************************************************************
* File Name: Pin_laser_read.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Pin_laser_read_H) /* Pins Pin_laser_read_H */
#define CY_PINS_Pin_laser_read_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Pin_laser_read_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Pin_laser_read__PORT == 15 && ((Pin_laser_read__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Pin_laser_read_Write(uint8 value);
void    Pin_laser_read_SetDriveMode(uint8 mode);
uint8   Pin_laser_read_ReadDataReg(void);
uint8   Pin_laser_read_Read(void);
void    Pin_laser_read_SetInterruptMode(uint16 position, uint16 mode);
uint8   Pin_laser_read_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Pin_laser_read_SetDriveMode() function.
     *  @{
     */
        #define Pin_laser_read_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Pin_laser_read_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Pin_laser_read_DM_RES_UP          PIN_DM_RES_UP
        #define Pin_laser_read_DM_RES_DWN         PIN_DM_RES_DWN
        #define Pin_laser_read_DM_OD_LO           PIN_DM_OD_LO
        #define Pin_laser_read_DM_OD_HI           PIN_DM_OD_HI
        #define Pin_laser_read_DM_STRONG          PIN_DM_STRONG
        #define Pin_laser_read_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Pin_laser_read_MASK               Pin_laser_read__MASK
#define Pin_laser_read_SHIFT              Pin_laser_read__SHIFT
#define Pin_laser_read_WIDTH              1u

/* Interrupt constants */
#if defined(Pin_laser_read__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Pin_laser_read_SetInterruptMode() function.
     *  @{
     */
        #define Pin_laser_read_INTR_NONE      (uint16)(0x0000u)
        #define Pin_laser_read_INTR_RISING    (uint16)(0x0001u)
        #define Pin_laser_read_INTR_FALLING   (uint16)(0x0002u)
        #define Pin_laser_read_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Pin_laser_read_INTR_MASK      (0x01u) 
#endif /* (Pin_laser_read__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Pin_laser_read_PS                     (* (reg8 *) Pin_laser_read__PS)
/* Data Register */
#define Pin_laser_read_DR                     (* (reg8 *) Pin_laser_read__DR)
/* Port Number */
#define Pin_laser_read_PRT_NUM                (* (reg8 *) Pin_laser_read__PRT) 
/* Connect to Analog Globals */                                                  
#define Pin_laser_read_AG                     (* (reg8 *) Pin_laser_read__AG)                       
/* Analog MUX bux enable */
#define Pin_laser_read_AMUX                   (* (reg8 *) Pin_laser_read__AMUX) 
/* Bidirectional Enable */                                                        
#define Pin_laser_read_BIE                    (* (reg8 *) Pin_laser_read__BIE)
/* Bit-mask for Aliased Register Access */
#define Pin_laser_read_BIT_MASK               (* (reg8 *) Pin_laser_read__BIT_MASK)
/* Bypass Enable */
#define Pin_laser_read_BYP                    (* (reg8 *) Pin_laser_read__BYP)
/* Port wide control signals */                                                   
#define Pin_laser_read_CTL                    (* (reg8 *) Pin_laser_read__CTL)
/* Drive Modes */
#define Pin_laser_read_DM0                    (* (reg8 *) Pin_laser_read__DM0) 
#define Pin_laser_read_DM1                    (* (reg8 *) Pin_laser_read__DM1)
#define Pin_laser_read_DM2                    (* (reg8 *) Pin_laser_read__DM2) 
/* Input Buffer Disable Override */
#define Pin_laser_read_INP_DIS                (* (reg8 *) Pin_laser_read__INP_DIS)
/* LCD Common or Segment Drive */
#define Pin_laser_read_LCD_COM_SEG            (* (reg8 *) Pin_laser_read__LCD_COM_SEG)
/* Enable Segment LCD */
#define Pin_laser_read_LCD_EN                 (* (reg8 *) Pin_laser_read__LCD_EN)
/* Slew Rate Control */
#define Pin_laser_read_SLW                    (* (reg8 *) Pin_laser_read__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Pin_laser_read_PRTDSI__CAPS_SEL       (* (reg8 *) Pin_laser_read__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Pin_laser_read_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Pin_laser_read__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Pin_laser_read_PRTDSI__OE_SEL0        (* (reg8 *) Pin_laser_read__PRTDSI__OE_SEL0) 
#define Pin_laser_read_PRTDSI__OE_SEL1        (* (reg8 *) Pin_laser_read__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Pin_laser_read_PRTDSI__OUT_SEL0       (* (reg8 *) Pin_laser_read__PRTDSI__OUT_SEL0) 
#define Pin_laser_read_PRTDSI__OUT_SEL1       (* (reg8 *) Pin_laser_read__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Pin_laser_read_PRTDSI__SYNC_OUT       (* (reg8 *) Pin_laser_read__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Pin_laser_read__SIO_CFG)
    #define Pin_laser_read_SIO_HYST_EN        (* (reg8 *) Pin_laser_read__SIO_HYST_EN)
    #define Pin_laser_read_SIO_REG_HIFREQ     (* (reg8 *) Pin_laser_read__SIO_REG_HIFREQ)
    #define Pin_laser_read_SIO_CFG            (* (reg8 *) Pin_laser_read__SIO_CFG)
    #define Pin_laser_read_SIO_DIFF           (* (reg8 *) Pin_laser_read__SIO_DIFF)
#endif /* (Pin_laser_read__SIO_CFG) */

/* Interrupt Registers */
#if defined(Pin_laser_read__INTSTAT)
    #define Pin_laser_read_INTSTAT            (* (reg8 *) Pin_laser_read__INTSTAT)
    #define Pin_laser_read_SNAP               (* (reg8 *) Pin_laser_read__SNAP)
    
	#define Pin_laser_read_0_INTTYPE_REG 		(* (reg8 *) Pin_laser_read__0__INTTYPE)
#endif /* (Pin_laser_read__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Pin_laser_read_H */


/* [] END OF FILE */
