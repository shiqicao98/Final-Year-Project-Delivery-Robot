/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/



float A[83][69];

void put_in_map(int lable,int r_p,int r_n,int c_p,int c_n){
    
for(int i = r_n;i < r_p;i++){
            for(int j = c_n;j < c_p;j++){
                A[i][j] = lable;

            }
            
        }

}
void creat_map(){
    for(int i = 0;i < 83;i++){
            for(int j = 0;j < 69;j++){
                A[i][j] = 11;

            }
            
        }
put_in_map(1,31,0,31,0);
put_in_map(2,55,31,69,0);
put_in_map(3,32,0,69,42);
put_in_map(4,83,55,55,38);
put_in_map(5,83,66,40,0);

put_in_map(0,31,0,9,0);
put_in_map(0,31,22,21,9);
put_in_map(0,32,0,42,31);
put_in_map(0,83,25,69,51);
put_in_map(0,66,55,40,0);
put_in_map(0,83,73,40,0);

}


/* [] END OF FILE */
