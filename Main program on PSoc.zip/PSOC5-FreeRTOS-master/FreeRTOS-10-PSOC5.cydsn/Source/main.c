/* ========================================
 *
 * Copyright 2018 Michael McCormack
 * All Rights Reserved
 *
 * Permission is hereby granted, free of charge, to any person obtaining 
 * a copy of this software and associated documentation files (the "Software"), 
 * to deal in the Software without restriction, including without limitation 
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, 
 * and/or sell copies of the Software, and to permit persons to whom the 
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included 
 * in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ========================================
*/
# define ADDRESS_XU 0x0000
# define ADDRESS_XL 0x0001
# define ADDRESS_YU 0x0002
# define ADDRESS_YL 0x0003
int address_shift_number = 0;
int scope;
#include <stdlib.h>

#include "project.h"
#include "FreeRTOS.h"
#include "timers.h"
#include "semphr.h"
#include "croutine.h"
#include <string.h>
#include <stdint.h>
#include "task.h"
#include "queue.h"
#include "event_groups.h"
#include <stdio.h>
#include <mpu6050.h>
#include <math.h>
#include <VL53L0X.h>
#include "FreeRTOS.h"
#include "variables.h"
#include "functions.h"
float offset = 0;
int wall_flag = 0;
int limit_1;
int limit_2;
int ULTRA;
int dist_measure_flag = 50;

SemaphoreHandle_t Task_2_3_s;
SemaphoreHandle_t Task_1_2_s;
SemaphoreHandle_t Task_2_4_s;
SemaphoreHandle_t Task_2_1_s;
SemaphoreHandle_t Task_3_2_s;
SemaphoreHandle_t Task_end_s;
SemaphoreHandle_t Task_start_s;
SemaphoreHandle_t distance;
SemaphoreHandle_t along;
SemaphoreHandle_t Task_4_2_s;
SemaphoreHandle_t Task_4_5_s;
SemaphoreHandle_t Task_5_4_s;
//imu
//----------------------------------------
//Ratios de conversion
float IMU_anglevel_deg;
#define A_R 16384.0   //Conversion del aceleracion
#define G_R 131.07     //Conversion del giroscopio 

//Conversion de radianes y grados 
#define RAD_TO_DEG  57.2957795
#define DEG_TO_RAD 0.017453

int16_t CAX, CAY, CAZ; 
int16_t CGX, CGY, CGZ;
float Angle=0;   //Angulo inicial
float Ang = 0;
float aim_theta = 0;
int count_times_staterun = 0;
uint16 barcode[40];
int ind_barcode = 0;
//---------------------------------------------------
//ranger
//------------------------------------------------------
//Use in timed(continuous) or single mode

int dist = 0;
int dist2 = 0;
int dist3 = 0;
//========================task flag===================
int start_area = 0;
int end_area = 0;
int start_task_flag = 0;
//=====================================================
//--------------------------------------------------------
extern void RTOS_Start(void);
int ct=0;
int check_receive = 0;
int readdata;
int upper_readdata;
int lower_readdata;
int upper_readdata2;
int lower_readdata2;
int upper_readdata3;
int lower_readdata3;
int end_task_flag = 0;
void turn(float aim_theta);

float convert_theta2_0_360();
void give_PWM(int speed_pwm,int speed_pwm_2){
PWM_1_WriteCompare1(speed_pwm);  //1000    
PWM_1_WriteCompare2(speed_pwm_2);//930
}
// move the robot to a told coordinate directly
void move(float destination_x,float destination_y,int speed_level){
    float angle_destination = atan2f(destination_y - y,destination_x - x);
    if(angle_destination < 0){angle_destination = angle_destination + 2*M_PI;}
    turn(angle_destination);
    give_PWM(speed_level,speed_level);
    while(pow(x-destination_x,2) > 0.0025 || pow(y-destination_y,2) > 0.0025)
    {
        give_PWM(speed_level,speed_level);
        left_forward();
        right_forward();
        angle_destination = atan2f(destination_y - y,destination_x - x);
        if(angle_destination < 0){angle_destination = angle_destination + 2*M_PI;}
        if(pow(angle_destination - convert_theta2_0_360(),2) > 0.005){
            
            turn(angle_destination);
            give_PWM(speed_level,speed_level);
            left_forward();
            right_forward();
        }
    }
    left_stop();
    right_stop();
}
//=======================================
// control the distance from the wall
void PID(int distance,int wall,int speed_level){
    distance = fabs(cos(convert_theta2_0_360() - aim_theta) * distance);
    P_distance = distance;
    delt_dist_B = delt_dist;
    if(distance < limit_1){delt_dist = distance - limit_1;}
    else if(dist > limit_2){delt_dist = distance - limit_2;}
    else{
        D_i = 0;
        PWM_left = speed_level-5;
        speed_delt = 0;
        delt_dist_B = 0;
        if(fabs(convert_theta2_0_360() - aim_theta) < 0.3 || (convert_theta2_0_360() - aim_theta < - (2*M_PI - 0.3)) || (convert_theta2_0_360() - aim_theta > (2*M_PI - 0.3)))
        {

        }
        else{
            delt_dist = 0;
            D_i = 0;
            PWM_left = speed_level-5;
            speed_delt = 0;
            delt_dist_B = 0;
            turn(aim_theta);
            left_forward();
            right_forward();
        }
        
    }
    
    if(fabs(convert_theta2_0_360() - aim_theta) < 0.3 || (convert_theta2_0_360() - aim_theta < - (2*M_PI - 0.3)) || (convert_theta2_0_360() - aim_theta > (2*M_PI - 0.3)))
    {

    }else{
        delt_dist = 0;
        D_i = 0;
        PWM_left = speed_level-5;
        speed_delt = 0;
        delt_dist_B = 0;
        turn(aim_theta);
        left_forward();
        right_forward();
    }
    
    
    D_p = delt_dist;
    D_i += delt_dist;
    D_d = delt_dist - delt_dist_B;
    speed_delt = (0.1067 * D_p + 0.33 * D_d);
    
    if(wall == 1){
        PWM_left = PWM_left - speed_delt;
    }
    else if (wall == 2){
        PWM_left = PWM_left + speed_delt;
    }
    
    if(PWM_left > speed_level + 70){PWM_left = speed_level + 70;}
    if(PWM_left < speed_level - 70){PWM_left = speed_level - 70;}
    
    
}
// =======================================
// adjust the front distance to a told value
void adjust_forward(float dis){
    while( pow(dist2 - dis,2) > 400 ){
    while(dist2 < dis){
        right_backward();
        left_backward();
        PWM_1_WriteCompare1(260);  //1000    
        PWM_1_WriteCompare2(261);//930
        
    }
    
    while(dist2 > dis){
        right_forward();
        left_forward();
        PWM_1_WriteCompare1(260);  //1000    
        PWM_1_WriteCompare2(260);//930
        
    }

    }
    left_stop();
    right_stop();

}
//=======================================
// calculate the smaller angle between theta and aim theta
float get_the_diff(float theta_1,float aim_1)
{
    float diff_RA = fabs(aim_1 - theta_1);
    
    if(diff_RA > M_PI){diff_RA = 2 * M_PI - diff_RA;}
    
    return diff_RA;
    
}
//=======================================
// convert theta value into range 0 to 360
float convert_theta2_0_360()
{
    float theta0_360 = theta;
    int theta_int = theta * 1000;
    int mtpl = theta_int/6284;
    if(theta < 0){theta0_360 = theta - mtpl*2*M_PI + 2*M_PI;}
    else if(theta > 2*M_PI){theta0_360 = theta - mtpl*2*M_PI;}
    
    
    
    return theta0_360;
}
// turn function=======================
// the robot can turn to a told orientation
void turn(float aim_theta){
    dist_measure_flag = 10;
    float theta0_360 = convert_theta2_0_360();
    left_stop();
    right_stop();
    PWM_1_WriteCompare1(350);  //1000    
    PWM_1_WriteCompare2(350);//930
    
    
    
    float small_angle_distance =  get_the_diff(theta0_360,aim_theta);
    float small_angle_distance_temp = get_the_diff(theta0_360,aim_theta)+1;
    
    theta0_360 = convert_theta2_0_360();
    if(theta0_360 > aim_theta)
    {
        theta0_360 = convert_theta2_0_360();
        if(theta0_360 - aim_theta>=M_PI)
        {
            while(small_angle_distance_temp > small_angle_distance || small_angle_distance > 0.06){
                left_backward();
                right_forward();
                
                small_angle_distance_temp = small_angle_distance;
                theta0_360 = convert_theta2_0_360();
                small_angle_distance = get_the_diff(theta0_360,aim_theta);
                scope = small_angle_distance * 1000;
            }
        }
        else
        {
            while(small_angle_distance_temp > small_angle_distance || small_angle_distance > 0.06){
                right_backward();
                left_forward();
                small_angle_distance_temp = small_angle_distance;
                theta0_360 = convert_theta2_0_360();
                small_angle_distance = get_the_diff(theta0_360,aim_theta);
                scope = small_angle_distance * 1000;
            }
        }
    }else{
        
        theta0_360 = convert_theta2_0_360();
        if( aim_theta - theta0_360>=M_PI)
        {
            while(small_angle_distance_temp >= small_angle_distance || small_angle_distance > 0.06){
                right_backward();
                left_forward();
                small_angle_distance_temp = small_angle_distance;
                theta0_360 = convert_theta2_0_360();
                small_angle_distance = get_the_diff(theta0_360,aim_theta);
                scope = small_angle_distance * 1000;
            }
        }
        else
        {
            
            while(small_angle_distance_temp >= small_angle_distance || small_angle_distance > 0.07){
                
                left_backward();
                right_forward();
                small_angle_distance_temp = small_angle_distance;
                theta0_360 = convert_theta2_0_360();
                small_angle_distance = get_the_diff(theta0_360,aim_theta);
                scope = small_angle_distance * 1000;
                
            }
        }
    
    }  
    left_stop();
    right_stop();
    
    dist_measure_flag = 50;
    
}
// The original method to adjust distance from wall
void allongthewall(int D,int W){
    float T;
    if((D > limit_1 && D < limit_2 ) || (D > 8000))
            { }
            else {
                if(W == 1){
                T = aim_theta + M_PI/2;
                if(T < 0){T  = T + 2*M_PI;}
                if(T > 2*M_PI){T  = T - 2*M_PI;}
                turn(T);
                if(dist2 < 700){adjust_forward((limit_1 + limit_2)/2 + 40);}
                turn(aim_theta);
                }
                if(W == 2){
                T = aim_theta - M_PI/2;
                if(T < 0){T  = T + 2*M_PI;}
                if(T > 2*M_PI){T  = T - 2*M_PI;}
                turn(T);
                if(dist2 < 700){adjust_forward((limit_1 + limit_2)/2 + 60);}
                turn(aim_theta);
                }
                
            }

        CyDelay(100);

}
//===interrept==ISR==========

//===========================
// receive 3 distances
CY_ISR(receive_laser){
    
    readdata = UART_1_ReadRxData();
    if(readdata == 0xff){
    check_receive = 0;
    }
    
    else if(check_receive == 1){
        lower_readdata = readdata;
    }
    else if(check_receive == 2){
        upper_readdata = readdata;
        dist = upper_readdata * 100 + lower_readdata;

    }
    
    else if(check_receive == 3){
        lower_readdata2 = readdata;
    }
    else if(check_receive == 4){
        upper_readdata2 = readdata;
        dist2 = upper_readdata2 * 100 + lower_readdata2;

    }
    else if(check_receive == 5){
        lower_readdata3 = readdata;
    }
    else if(check_receive == 6){
        upper_readdata3 = readdata;
        dist3 = upper_readdata3 * 100 + lower_readdata3;

    }
    check_receive++;
}
//=======================================================
// receive barcode
CY_ISR(receive_barcode){
   int barcode_temp ;
   char barcode_temp_str = UART_barcode_GetChar();
   int recieve_temp = barcode_temp_str;
    barcode_temp = atoi(&barcode_temp_str);
    float Decile_temp =0;
    if(barcode_counter == 0){bar_x_start = barcode_temp;}
    if(barcode_counter == 1){
        Decile_temp = barcode_temp;
        bar_x_start += Decile_temp/10;
    }
    if(barcode_counter == 2){bar_y_start = barcode_temp;}
    if(barcode_counter == 3){
        Decile_temp = barcode_temp;
        bar_y_start += Decile_temp/10;
        
    }
    if(barcode_counter == 4){bar_x_end = barcode_temp;}
    if(barcode_counter == 5){
        Decile_temp = barcode_temp;
        bar_x_end += Decile_temp/10;
        
    }
    if(barcode_counter == 6){bar_y_end = barcode_temp;}
    if(barcode_counter == 7){
        Decile_temp = barcode_temp;
        bar_y_end += Decile_temp/10;
        
    }
    if(barcode_counter == 8){barcode_counter = -1;
        if(recieve_temp == 97){
        start_x = bar_x_start;
        start_y = bar_y_start;
        }
        else if(recieve_temp == 98){
        start_x = x;
        start_y = y;
        }
        barcode_temp = 0;
        barcode_temp_str = 0;
        Decile_temp = 0;
        int bbbb = bar_y_start * 10;
        int ccc = bar_x_end * 10;
        x_end = bar_x_end;
        int ddd = bar_y_end * 10;
        y_end = bar_y_end;
        
        start_task_flag = 1;
    }
    barcode_counter ++;
    
}

//-------------------------------------------------------
//Tasks----------------------------------------------------
/*
void I2C_Task(void *arg)
{
    (void)arg;
    while(1)
    {
        
        if(dist_measure_flag == 50 ){
        //dist = VL53L0X_readRangeContinuousMillimeters();
        }
        
        vTaskDelay(10);
        
    }
}
*/
// in this task we save x y data into EEPROM
void LED_Task(void *arg)
{
    (void)arg;
    while(1)
    {
        LED_Write(~LED_Read());
        
        
        int p_x = x * 10;
        int p_y = y * 10;
        int p_theta = theta * 10;

        int x_ROM_long =  round(x * 100);
        int y_ROM_long =  round(y * 100);
        
        int x_ROM_upper = x_ROM_long /100;
        int x_ROM_lower = x_ROM_long - x_ROM_upper * 100;
        int y_ROM_upper = y_ROM_long /100;
        int y_ROM_lower = y_ROM_long - y_ROM_upper * 100;
        if(end_task_flag == 1){
            EEPROM_WriteByte(98, ADDRESS_XU + address_shift_number);
            EEPROM_WriteByte(76, ADDRESS_XL + address_shift_number);
            EEPROM_WriteByte(54, ADDRESS_YU + address_shift_number);    
            EEPROM_WriteByte(32, ADDRESS_YL + address_shift_number);
            end_task_flag = 0;
        }
        else{
        EEPROM_WriteByte(x_ROM_upper, ADDRESS_XU + address_shift_number);
        EEPROM_WriteByte(x_ROM_lower, ADDRESS_XL + address_shift_number);
        EEPROM_WriteByte(y_ROM_upper, ADDRESS_YU + address_shift_number);
        EEPROM_WriteByte(y_ROM_lower, ADDRESS_YL + address_shift_number);
        }
        address_shift_number += 4;
        vTaskDelay(300);  
        
    }
}
/*
void Along_wall_Task(void *arg)
{
    (void)arg;
    while(1)
    {
        
        if(0)
        {
            
            if((dist > limit_1 && dist < limit_2 ) || (dist > 8000))
            { }
            else {
                
                turn(aim_theta + M_PI/2);
                
                if(distance_measured_filter < 95)
                {
                adjust_forward(ULTRA);
                }
                
                turn(aim_theta);
                
            } 
        }
        UART_PutString("xxxxx\n");
        vTaskDelay(500);  
        
    }
}
*/
/*
void ULTRA_Task(void *arg)
{
    (void)arg;
    while(1)
    {
        
        float t_distance;
        float flat = 0;
        float max = 0;
        float min = 100000;
        for(int i = 0; i < 7; i ++){
             while(Echo_Read() == 0)
             {
             trigger_Write(1);
             CyDelayUs(10);
             trigger_Write(0);
             }
            
            t_distance = distance_measured;
            if(max < t_distance){
            max = t_distance;
            }
            if(min > t_distance){
            min = t_distance;
            }
            flat = flat+ t_distance;
        }   
        flat = (flat-min-max)*0.2; 
        distance_measured_filter =  flat; 
         
        vTaskDelay(100);
    }
}
*/

void Task_start(void *arg) // start task
{
    (void)arg;
    while(1)
    {
        xSemaphoreTake(Task_start_s,portMAX_DELAY);
        /*
        aim_theta = 0;
        turn(aim_theta);
        limit_1 = 240;
        limit_2 = 270;
        PWM_left = 410;
        PWM_right = 395;
        while(dist < 800){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist,1,400);
            //allongthewall(dist,1);
            CyDelay(100);
        }
        */
        
        
        while(start_task_flag == 0){}
        int start_x_int = start_x * 10;
        int start_y_int = start_y * 10;
        int end_x_int = x_end * 10;
        int end_y_int = y_end * 10;
        start_area = A[start_x_int][start_y_int];
        end_area = A[end_x_int][end_y_int];
        
         
        x = start_x;
        y = start_y;
        
        float x_plus;
        float y_plus;
        x_plus = x + 0.2;
        give_PWM(400,410);
        while(x < x_plus)
        {
            
            left_forward();
            right_forward();
        }
        
        
        if(start_area == 1)
        {
            
            move(0.4,2.9,400);
            turn(0);
            xSemaphoreGive(Task_1_2_s);
        }
        else if(start_area == 2)
        {
            move(3.3,3.3,400);
            if(end_area == 1){xSemaphoreGive(Task_2_1_s);}
            if(end_area == 3){xSemaphoreGive(Task_2_3_s);}
            if(end_area == 4 || end_area == 5){xSemaphoreGive(Task_2_4_s);}
            
        }
        else if(start_area == 3)
        {
            move(1.8,6.6,400);
            turn(1.5*M_PI);
            xSemaphoreGive(Task_3_2_s);
        }
        else if(start_area == 4)
        {
            move(5.6,4,400);
            if(end_area == 1 || end_area == 2 || end_area == 3){xSemaphoreGive(Task_4_2_s);}
            if(end_area == 5){xSemaphoreGive(Task_4_5_s);}
        }
        else if(start_area == 5)
        {
            move(6.75,1.2,300);
            xSemaphoreGive(Task_5_4_s);
        }
        
    }
}
//====================================================
//Move from area 1 to area 2
void Task_1_2(void *arg)
{
    (void)arg;
    while(1)
    {
        xSemaphoreTake(Task_1_2_s,portMAX_DELAY);
        float x_plus;
        float y_plus;
        aim_theta = 0;
        turn(aim_theta);
        limit_1 = 260;
        limit_2 = 300;
        PWM_left = 400;
        PWM_right = 400;
        while(dist < 800){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist,1,400);
            CyDelay(150);
        }
        
        left_stop();
        right_stop();
        turn(0);
        
        
        x_plus = x + 0.2;
        while(x < x_plus){
            left_forward();
            right_forward();
        }
        left_stop();
        right_stop();
        turn(M_PI/2);
        float dist_temp = dist;
        while(dist > 800){
            give_PWM(400,410);
            left_forward();
            right_forward();
            dist_temp = dist;
            temp_data_dist = dist;
        }
        
        CyDelay(300);
        
        left_stop();
        right_stop();
        turn(M_PI/2);
        CyDelay(100);
        dist_temp = dist;
        //update state============================================
        x = 3.14 + (dist_temp-20)/1000;
        y = 3.34;
        //========================================================
        //================================================
        if(end_area == 3){xSemaphoreGive(Task_2_3_s);}
        if(end_area == 4 || end_area == 5){xSemaphoreGive(Task_2_4_s);}
        if(end_area == 2){xSemaphoreGive(Task_end_s);}
        //================================================
    
    }
}
//====================================================
//Move from area 2 to area 3
void Task_2_3(void *arg)
{
    (void)arg;
    while(1)
    {
        xSemaphoreTake(Task_2_3_s,portMAX_DELAY);
        
        ULTRA = 25;
        limit_1 = 170;
        limit_2 = 320;
        aim_theta = M_PI/2;
        turn(aim_theta);
        PWM_left = 400;
        PWM_right = 400;
        while(dist < 800){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist,1,400);
            CyDelay(150);
        }
        left_stop();
        right_stop();
        turn(aim_theta);
        
        adjust_forward(370);
        
        turn(M_PI);
        limit_1 = 260;
        limit_2 = 450;
        aim_theta = M_PI;
        while(dist3 < 800){
            give_PWM(400,415);
            left_forward();
            right_forward();
            allongthewall(dist3,2);
        }
        
        left_stop();
        right_stop();
        
        
        while(dist3 > 800){
            give_PWM(250,252);
            left_backward();
            right_backward();
        }
        CyDelay(150);
        turn(M_PI/2);
        adjust_forward(170);
        turn(M_PI);
        
        while(dist2 > 400){
            give_PWM(280,280);
            left_forward();
            right_forward();
            }
        turn(M_PI/2);
        
        float y_plus2 = y + 0.20;
        while(y < y_plus2){
            give_PWM(400,395);
            left_forward();
            right_forward();
        }
        left_stop();
        right_stop();
        turn(M_PI);
        adjust_forward(340);
        turn(M_PI/2);
        limit_1 = 220;
        limit_2 = 400;
        
        aim_theta = M_PI/2;
        PWM_left = 400;
        PWM_right = 400;
        while(dist < 1000){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist,1,400);
            CyDelay(150);
        }
        left_stop();
        right_stop();
        adjust_forward(360);
        turn(0);
        adjust_forward(300);
        left_stop();
        right_stop();
        turn(0);
        CyDelay(50);
        //=================update======================
        float dist2_f = dist2;
        float dist_f = dist;
        x = 2.36 - 0.22 - dist2_f/1000;
        y = 6.84 - dist_f/1000 + 0.02;
        //=============================================
        //======================
        xSemaphoreGive(Task_end_s);
        //======================
        
        
        
        
    }
}
//====================================================
//Move from area 2 to area 4
void Task_2_4(void *arg)
{
    (void)arg;
    while(1)
    {   xSemaphoreTake(Task_2_4_s,portMAX_DELAY);
        
        limit_1 = 260;
        limit_2 = 350;
        aim_theta = M_PI/2;
        turn(M_PI);
        adjust_forward((limit_1 + limit_2)/2);
        turn(aim_theta);
        PWM_left = 400;
        PWM_right = 400;
        while(dist < 700){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist,1,400);
            CyDelay(150);
        }
        
        left_stop();
        right_stop();
        turn(aim_theta);
        
        //door 
        
        limit_1 = 330;
        limit_2 = 360;
        adjust_forward((limit_1 + limit_2 + 35)/2);
        turn(0);
        aim_theta = 0;
        while(dist3 > 1200){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist,1,400);
            CyDelay(150);
        }
        turn(0);
        
        while(dist3 < 1200){
            left_backward();
            right_backward();
            give_PWM(308,300);
        }
        //===========================
        x = 5.6;
        //============================
        float x_plus = x + 0.3;
        turn(0);
        while(x < x_plus){
            left_forward();
            right_forward();
            give_PWM(410,397);
        }
        turn(M_PI * 1.5);
        adjust_forward(300);
        turn(0);
        
        float dist_temp = dist3;
        CyDelay(100);
        //=============update============
        y = 3.9 + (dist_temp-20)/1000;
        //===============================
        if(end_area == 5){xSemaphoreGive(Task_4_5_s);}
        if(end_area == 4){xSemaphoreGive(Task_end_s);}
        //===============================
    }
}
//====================================================
//Move from area 2 to area 1
void Task_2_1(void *arg)
{
    (void)arg;
    while(1)
    {   xSemaphoreTake(Task_2_1_s,portMAX_DELAY);
        // wall tableright side
        limit_1 = 170;
        limit_2 = 320;
        aim_theta = M_PI * 1.5;
        turn(aim_theta);
        while(dist3 < 800){
            give_PWM(400,400);
            left_forward();
            right_forward();
            
        }
        
        
        float y_plus = y - 0.35;
        while(y > y_plus){
            give_PWM(400,400);
            left_forward();
            right_forward();
        }
        turn(M_PI);
        while(dist3 > 700){
            give_PWM(400,400);
            left_forward();
            right_forward();
        }
        // wall TV 
        limit_1 = 250;
        limit_2 = 350;
        aim_theta = M_PI;
        PWM_left = 400;
        PWM_right = 400;
        while(dist2 > 300){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist3,2,400);
            if(dist3 < 200)
            {
                turn(M_PI/2);
                adjust_forward((limit_1 + limit_2 + 30)/2);
                turn(M_PI);
            }
            CyDelay(50);
        }
        adjust_forward(560);
        left_stop();
        right_stop();
        turn(M_PI);
        //=========================update===================
        float dist2_f = dist2;
        float dist3_f = dist3;
        x = dist2_f/1000 - 0.16;
        y = 3.15 - dist3_f/1000;
        //==================================================
        //======================
        xSemaphoreGive(Task_end_s);
        //======================
    
        
        
    }
}
//====================================================
//Move from area 3 to area 2
void Task_3_2(void *arg)
{
    (void)arg;
    while(1)
    {   
        
        
        xSemaphoreTake(Task_3_2_s,portMAX_DELAY);
        float x_plus;
        float y_plus;
        
        limit_1 = 280;
        limit_2 = 340;
        aim_theta = M_PI * 1.5;
        turn(0);
        adjust_forward((limit_1 + limit_2 + 40)/2);
        turn(aim_theta);
        
        PWM_left = 350;
        PWM_right = 350;
        while(dist < 1000){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist,1,350);
            CyDelay(110);
        }
        turn(1.5*M_PI);
        while(dist > 600){
            give_PWM(400,400);
            left_backward();
            right_backward();
        }
        y_plus = y + 0.1;
        while(y < y_plus){
            give_PWM(300,300);
            left_backward();
            right_backward();
        }
        turn(0);
        // close to wall 
        adjust_forward(230);
        turn(M_PI * 1.5);
        while(dist < 900){
            give_PWM(400,410);
            left_forward();
            right_forward();
        }
        
        y_plus = y - 0.22;
        while(y > y_plus){
            give_PWM(410,400);
            left_forward();
            right_forward();
        }
        turn(0);
        // door room 
        limit_1 = 250;
        limit_2 = 350;
        aim_theta = 0;
        while(dist3 < 700){
            give_PWM(400,400);
            left_forward();
            right_forward();
            CyDelay(200);
            allongthewall(dist3,2);
        }
        left_stop();
        right_stop();
        
        x_plus = x + 0.2;
        while(x < x_plus){
            give_PWM(400,400);
            left_forward();
            right_forward();
        }
        turn(M_PI * 1.5);
        while(dist3 > 700){
            give_PWM(400,400);
            left_forward();
            right_forward();
        }
        // wall table right
        limit_1 = 200;
        limit_2 = 320;
        aim_theta = M_PI * 1.5;
        turn(M_PI);
        adjust_forward((limit_1 + limit_2 + 40)/2);
        turn(aim_theta);
        PWM_left = 400;
        PWM_right = 400;
        while(dist3 < 800){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist3,2,400);
            CyDelay(150);
        }
        
        left_stop();
        right_stop();
        turn(M_PI/2);
        while(dist < 1000){
            give_PWM(300,300);
            left_backward();
            right_backward();
        }
        while(dist > 1000){
            give_PWM(300,300);
            left_forward();
            right_forward();
        }
        CyDelay(300);
        float dist_temp = dist;
        //====================update=====================
        x = 3.14 + (dist_temp-20)/1000;
        y = 3.34;
        temp_data_x = x * 1000;
        temp_data_y = y * 1000;
        //================================================
        
        
        if(end_area == 1){xSemaphoreGive(Task_2_1_s);}
        if(end_area == 4 || end_area == 5){xSemaphoreGive(Task_2_4_s);}
        if(end_area == 2){xSemaphoreGive(Task_end_s);}
        //================================================
    }
}
//====================================================
//Move from area 4 to area 2
void Task_4_2(void *arg)
{
    (void)arg;
    while(1)
    {
        xSemaphoreTake(Task_4_2_s,portMAX_DELAY);
        turn(M_PI);
        while(dist < 1000){
            left_forward();
            right_forward();
            give_PWM(280,280);
            
        }
        move(3.4,3.5,400);
        limit_1 = 260;
        limit_2 = 320;
        aim_theta = M_PI * 1.5;
        turn(M_PI);
        adjust_forward((limit_1 + limit_2 + 40)/2);
        turn(aim_theta);
        PWM_left = 400;
        PWM_right = 400;
        while(dist3 < 800){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist3,2,400);
            CyDelay(120);
        }
        
        left_stop();
        right_stop();
        turn(M_PI/2);
        while(dist < 1000){
            give_PWM(300,300);
            left_backward();
            right_backward();
        }
        while(dist > 1000){
            give_PWM(300,300);
            left_forward();
            right_forward();
        }
        CyDelay(300);
        float dist_temp = dist;
        //====================update=====================
        x = 3.24 + (dist_temp-20)/1000;
        y = 3.28;
        temp_data_x = x * 1000;
        temp_data_y = y * 1000;
        //================================================
        //================================================
        if(end_area == 1){xSemaphoreGive(Task_2_1_s);}
        if(end_area == 3){xSemaphoreGive(Task_2_3_s);}
        if(end_area == 2){xSemaphoreGive(Task_end_s);}
        //================================================
        
    }
}
//====================================================
//Move from area 4 to area 5
void Task_4_5(void *arg)
{
    (void)arg;
    while(1)
    {
        xSemaphoreTake(Task_4_5_s,portMAX_DELAY);
        float x_plus,y_plus;
        turn(1.5 * M_PI);
        limit_1 = 240;
        limit_2 = 320;
        adjust_forward((limit_1 + limit_2)/2);
        aim_theta = 0;
        turn(0);
        PWM_left = 400;
        PWM_right = 400;
        while(dist3 < 660){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist3,2,400);
            CyDelay(150);
        }
        turn(0);
       
        x_plus = x+ 0.3;
        while(x < x_plus){
            left_forward();
            right_forward();
            give_PWM(280,280);
        }
        turn(1.5*M_PI);
        
        while(dist3 > 400){
            left_forward();
            right_forward();
            give_PWM(280,280);
        }
        PWM_left = 300;
        PWM_right = 300;
        aim_theta = 1.5*M_PI;
        limit_1 = 240;
        limit_2 = 320;
        while(dist2 > 500){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist3,2,300);
            CyDelay(150);
        }
        turn(aim_theta);
        float temp_dist2 = dist2;
        float temp_dist3 = dist3;
        //==========update============
        x = 6.56 + (temp_dist3 - 260)/1000;
        y = 1.04 + (temp_dist2 - 100)/1000;
        //============================
        xSemaphoreGive(Task_end_s);
        //======================
    }
}
void Task_5_4(void *arg) // Move from area 5 to area 4
{
    (void)arg;
    while(1)
    {
        xSemaphoreTake(Task_5_4_s,portMAX_DELAY);
        float x_plus,y_plus;
        turn(M_PI);
        limit_1 = 320;
        limit_2 = 380;
        adjust_forward((limit_1 + limit_2 + 40)/2);
        aim_theta = M_PI/2;
        turn(aim_theta);
        
        PWM_left = 300;
        PWM_right = 300;
        while(dist < 900){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist,1,300);
            CyDelay(150);
        }
        turn(aim_theta);
        y_plus = y + 0.3;
        while(y < y_plus){
            left_forward();
            right_forward();
            give_PWM(280,280);
        }
        turn(M_PI);
        while(dist > 800){
            left_forward();
            right_forward();
            give_PWM(400,400);
        }
        limit_1 = 360;
        limit_2 = 450;
        aim_theta = M_PI;
        PWM_left = 400;
        PWM_right = 400;
        while(dist < 800){
            left_forward();
            right_forward();
            give_PWM(PWM_left,PWM_right);
            PID(dist,1,400);
            CyDelay(120);
        }
        turn(aim_theta);
         while(dist > 800){
            left_backward();
            right_backward();
            give_PWM(280,280);
        }
        CyDelay(500);
        turn(M_PI);
        float dist_temp = dist;
        //=============update============
        x = 5.6;
        y = 3.8 + (dist_temp-30)/1000;
        //===============================
        turn(0);
        if(end_area == 1 || end_area == 2 || end_area == 3){xSemaphoreGive(Task_4_2_s);}
        if(end_area == 4){xSemaphoreGive(Task_end_s);}
        //===============================
    }
}
void state_Task(void *arg)
{
    (void)arg;
    UART_PutString("state_Task entered\n");
    while(1)
    {
        //================================================================
        // state estimated function ======================================
        MPU6050_getMotion6t(&CAX, &CAY, &CAZ, &CGX, &CGY, &CGZ,&t); 
        count_times_staterun++;
        IMU_anglevel_deg = -CGZ/G_R - offset;
        IMU_anglevel = IMU_anglevel_deg*1.01717;
        theta_6050 = theta_6050 + IMU_anglevel *dt;
        
        int count2_L = QuadDec_2_GetCounter();
        int count1_L = QuadDec_1_GetCounter();
        speed_1 =  1/dt *count1_L; // unit : count/s
        speed_2 =  1/dt *count2_L;
        
        QuadDec_1_SetCounter(0);
        QuadDec_2_SetCounter(0);
        float left_speed_m = wheel_radius *speed_2 * 3.1416 * 2 / 1300; // m / s
        float right_speed_m = wheel_radius*speed_1 * 3.1416 * 2 / 1300;
        
        angular_velocity =  IMU_anglevel*DEG_TO_RAD;// 
        linear_velocity = (left_speed_m + right_speed_m) / 2; // m /s
        if((angular_velocity) == 0){
            x  += cos(theta) * linear_velocity  * dt;
            y  += sin(theta)* linear_velocity * dt;
    
        }else{
            float R = linear_velocity/angular_velocity;
            float new_theta = angular_velocity * dt + theta;
            x  += R*(-sin(theta)+sin(new_theta));
            y  += R*(cos(theta)-cos(new_theta));
            theta = new_theta;
            
            }
        
        //-----------------------------------------------------------------
        // Kalman filter===================================================
        
        float newAngle = theta;
        float newRate = IMU_anglevel * DEG_TO_RAD;
        float rate = newRate - bias;
        angle += dt*rate;
        P_00 += dt * (dt*P_11 - P_01 - P_10 + Q_angle);
        P_01 -= dt * P_11;
        P_10 -= dt * P_11;
        P_11 += Q_bias * dt;
        float S = P_00 + R_measure;
        float K[2];
        K[0] = P_00 / S;
        K[1] = P_10 / S;
        float y = newAngle - angle;
        angle += K[0] * y;
        bias += K[1] * y;
        float P00_temp = P_00;
        float P01_temp = P_01;
        P_00 -= K[0] * P00_temp;
        P_01 -= K[0] * P01_temp;
        P_10 -= K[1] * P00_temp;
        P_11 -= K[1] * P01_temp;
        //theta_6050 = angle;
        theta = angle;
        theta = 1 * theta_6050*DEG_TO_RAD + 0 * theta;
        
        
        vTaskDelay(20);  
    }
}

void Task_end(void *arg)// this task was perfprmed when the robot arrived destination area
{
    (void)arg;
    while(1)
    {   
        xSemaphoreTake(Task_end_s,portMAX_DELAY);
        move(x_end,y_end,300); // move to destination point 
        turn(0);
        start_task_flag = 0;
        end_task_flag = 1;
        xSemaphoreGive(Task_start_s);
        
    }
}
void test_task(void *arg)
{
    (void)arg;
    while(1)
    {   
        vTaskDelay(200);  
    }
}
void semaphore_Task(void *arg)
{
    (void)arg;
    while(1) 
    {
        
        
    }
    
}
//--------------------------------------------------------
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    RTOS_Start();

    TIMER_Init();    
    TIMER_Start();
    I2C_Start();
    //start uart=======
    UART_Start();
    UART_barcode_Start();
    UART_1_Start();
    //==================
    EEPROM_Start();
    // IMU init
    CyDelay(100);
    MPU6050_init();
    MPU6050_initialize();
    UART_PutString("IMU");
    //===================
    PWM_1_Start();
    QuadDec_1_Start();
    QuadDec_2_Start();
    QuadDec_1_SetCounter(0);
    QuadDec_2_SetCounter(0);
// give x y theta initial value
    x = start_x;
    y = start_y;
    start_theta = 0;
    theta = start_theta * RAD_TO_DEG;
    theta_6050 = start_theta * RAD_TO_DEG;
//===============================    
    // creat map
    creat_map();
    // ISR start==================
    Timer_3_Start();
    isr_1_StartEx(receive_laser);
    isr_3_StartEx(receive_barcode);
    CyDelay(50);
    UART_PutString("initialised\n");
    // wait for button press=============
    while(Pin_button_Read() == 1){};
    //===================================
    //calibration IMU====================
    
    for(int k = 0;k < 6000;k++){ 
        MPU6050_getMotion6t(&CAX, &CAY, &CAZ, &CGX, &CGY, &CGZ,&t); 
        offset = offset -CGZ/G_R;
    }
    
    offset = offset/6000;
    //===================================
    UART_PutString("caliibration completed\n");

    // creat Semaphore===================
    distance = xSemaphoreCreateBinary();
    along = xSemaphoreCreateBinary();
    Task_2_3_s = xSemaphoreCreateBinary();
    Task_1_2_s = xSemaphoreCreateBinary();
    Task_2_4_s = xSemaphoreCreateBinary();
    Task_2_1_s = xSemaphoreCreateBinary();
    Task_3_2_s = xSemaphoreCreateBinary();
    Task_4_2_s = xSemaphoreCreateBinary();
    Task_4_5_s = xSemaphoreCreateBinary();
    Task_5_4_s = xSemaphoreCreateBinary();
    Task_end_s = xSemaphoreCreateBinary();
    Task_start_s = xSemaphoreCreateBinary();
    //=======================================
    xSemaphoreGive(Task_start_s);
    UART_PutString("Semaphore generated\n");
    for(;;)
    {
    xTaskCreate(LED_Task,"LED Task",configMINIMAL_STACK_SIZE,0,7,0);
    //xTaskCreate(test_task,"test_task",configMINIMAL_STACK_SIZE,0,2,0);
    //xTaskCreate(semaphore_Task,"Semaphore Task",configMINIMAL_STACK_SIZE,0,2,0);
    xTaskCreate(state_Task,"state Task",configMINIMAL_STACK_SIZE,0,10,0);
    xTaskCreate(Task_1_2,"Task_1_2 Task",configMINIMAL_STACK_SIZE,0,1,0);
    xTaskCreate(Task_2_3,"Task_2_3 Task",configMINIMAL_STACK_SIZE,0,1,0);
    xTaskCreate(Task_2_4,"Task_2_4 Task",configMINIMAL_STACK_SIZE,0,1,0);
    xTaskCreate(Task_2_1,"Task_2_1 Task",configMINIMAL_STACK_SIZE,0,1,0);
    xTaskCreate(Task_4_2,"Task_4_2 Task",configMINIMAL_STACK_SIZE,0,1,0);
    xTaskCreate(Task_4_5,"Task_4 _5 Task",configMINIMAL_STACK_SIZE,0,1,0);
    xTaskCreate(Task_5_4,"Task_5_4 Task",configMINIMAL_STACK_SIZE,0,1,0);
    xTaskCreate(Task_3_2,"Task_3_2 Task",configMINIMAL_STACK_SIZE,0,1,0);
    xTaskCreate(Task_end,"Task_end Task",configMINIMAL_STACK_SIZE,0,1,0);
    xTaskCreate(Task_start,"Task_start Task",configMINIMAL_STACK_SIZE,0,1,0);
    UART_PutString("task generated\n");
    vTaskStartScheduler();  // TODO Should never return, add reset after
    
    }
}

/* [] END OF FILE */
