# PSOC5-FreeRTOS
Starting place for a Cypress PSOC CY8CKIT-059 FreeRTOS 10 port
